# Smart-parking
This projet is developed during Labs of the subject IoT Architecture

By:

Henchir  Hatem

Mohammed Omar Najjar

Ben Taher Malek

Abid Eya

Under-graduated students, 
Embadded system and IoT Bachelors 


Under the supervision of:

Amira Henaien, 
Computer Science, Assistant Professor,
Higher Institute of Computer Science Mahdia(ISIMA),
University of Monastir Tunisia


Title of the project:
Smart Parking 

Description:
Smart Parking is a parking solution that can include
in-ground Smart Parking sensors.These devices are usually
embedded into parking spots or positioned next to them to detect
whether parking bays are free or occupied.This happens through real-time
data collection.The data is then transmitted to a smart parking mobile
application or website, which communicates the availability to its users 

Objectif:
The summary project entitled “Smart Parking” makes it 
possible to organize and manage its parking transactions.
This system will be an advantage and will bring convenience
to the admin by simply dealing with reserved or empty parking
spaces through the graphical interface.

List of devices:
-6 Ultrasonic  sensor HC-SR04
- DC motor 
-Arduino
-Raspberry 
-ESP8266


